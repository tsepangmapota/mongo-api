import React from 'react';
import { Link } from 'react-router-dom'; // Make sure to install react-router-dom
import './NavBar.css';
const Navbar = () => {
    return (
        <nav className="navbar">
            <div className="container">
                <h1>Management System</h1>
                <ul>
                    <li>
                        <Link to="/">ProcurementManagement</Link>
                    </li>
                    <li>
                        <Link to="/staff-management">Staff Management</Link>
                    </li>
                </ul>
            </div>
        </nav>
    );
};

export default Navbar;