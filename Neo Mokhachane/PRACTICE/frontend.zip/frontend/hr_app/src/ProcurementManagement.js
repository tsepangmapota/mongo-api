import React, { useState } from 'react';
 import './ProcurementManagement.css'; // Import your class

const ProcurementManagement = () => {
    const [procurementManagement] = useState(new ProcurementManagement());
    const [staffNumber, setStaffNumber] = useState('');
    const [fullName, setFullName] = useState('');
    const [qualification, setQualification] = useState('');
    const [type, setType] = useState('');
    const [output, setOutput] = useState([]);

    const handleAddStaff = async (e) => {
        e.preventDefault();
        await procurementManagement.addStaffMember(staffNumber, fullName);
        setOutput(prev => [...prev, `Added Staff: ${fullName} (Staff Number: ${staffNumber})`]);
        setStaffNumber('');
        setFullName('');
    };

    const handleAddQualification = async (e) => {
        e.preventDefault();
        await procurementManagement.addQualificationToStaff(staffNumber, qualification, type);
        setOutput(prev => [...prev, `Added Qualification: ${qualification} (${type}) to Staff Number: ${staffNumber}`]);
        setQualification('');
        setType('');
    };

    return (
        <div>
            <h2>Procurement Management</h2>
            <form onSubmit={handleAddStaff}>
                <input
                    type="text"
                    name="staffNumber"
                    value={staffNumber}
                    onChange={(e) => setStaffNumber(e.target.value)}
                    placeholder="Staff Number"
                    required
                />
                <input
                    type="text"
                    name="fullName"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Full Name"
                    required
                />
                <button type="submit">Add Staff</button>
            </form>

            <form onSubmit={handleAddQualification}>
                <input
                    type="text"
                    name="qualification"
                    value={qualification}
                    onChange={(e) => setQualification(e.target.value)}
                    placeholder="Qualification"
                    required
                />
                <select name="type" value={type} onChange={(e) => setType(e.target.value)} required>
                    <option value="">Select Type</option>
                    <option value="academic">Academic</option>
                    <option value="professional">Professional</option>
                </select>
                <button type="submit">Add Qualification</button>
            </form>

            <div id="output">
                {output.map((msg, index) => (
                    <p key={index}>{msg}</p>
                ))}
            </div>
        </div>
    );
};

export default ProcurementManagement;